# AI Health Dashboard
This project tracks wellness using C, Java, Python, and HTML.
