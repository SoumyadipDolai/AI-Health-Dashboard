#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int main(){ srand(time(0)); printf("Heart Rate: %d bpm\n", (rand()%40)+60); return 0;}