import random
print('Predicted Wellness Score:', random.randint(50,100))